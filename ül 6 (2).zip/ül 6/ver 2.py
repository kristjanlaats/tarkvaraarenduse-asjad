#kristjan.laats
import pygame
import sys

# Initsialiseeri pygame
pygame.init()

# Mängualuse laius ja kõrgus
WIDTH, HEIGHT = 640, 480

# Värvid
WHITE = (255, 255, 255)
LIGHT_BLUE = (173, 216, 230)

# Mänguaken
#ekraani seaded
screen=pygame.display.set_mode([WIDTH,HEIGHT])
pygame.display.set_caption("Klaviatuuriga juhtimine")
screen.fill(LIGHT_BLUE)
clock = pygame.time.Clock()

# Lae pildid
ball_img = pygame.image.load("ball.png")
pad_img = pygame.image.load("pad.png")

# Muuda palli ja aluse suurust
ball_img = pygame.transform.scale(ball_img, (20, 20))
pad_img = pygame.transform.scale(pad_img, (120, 20))

# Mänguobjektide algväärtused
ball_rect = ball_img.get_rect(center=(WIDTH // 2, HEIGHT // 2))
pad_rect = pad_img.get_rect(midbottom=(WIDTH // 2, int(HEIGHT / 1.5)))

# Kiirus ja suund
ball_speed = [5, 5]
pad_speed = 5

# Mängu oleku muutujad
score = 0

#koordinaadid ja kiirus
posX, posY = WIDTH/2, HEIGHT/2
speedX, speedY = 0, 0
directionX, directionY = 0, 0

game_over = False

# Mängutsükkel
while not game_over:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        #klahvivajutus
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RIGHT:
                directionX = "move_right"
            elif event.key == pygame.K_LEFT:
                directionX = "move_left"
            elif event.key == pygame.K_UP:
                directionY = "move_up"
            elif event.key == pygame.K_DOWN:
                directionY = "move_down"

        #klahvivajutuse vabastamine
        elif event.type == pygame.KEYUP:
            if event.key == pygame.K_RIGHT or event.key == pygame.K_LEFT:
                directionX = 0
            if event.key == pygame.K_UP or event.key == pygame.K_DOWN:
                directionY = 0

    #mängu piirjoonte tuvastamine
    if directionX == "move_left":
        if posX > 0:
            posX -= 3
    elif directionX == "move_right":
        if posX + 30 < WIDTH:
            posX += 3
    if directionY == "move_up":
        if posY > 0:
            posY -= 3
    elif directionY == "move_down":
        if posY + 30 < HEIGHT:
            posY += 3


    # Liiguta palli
    ball_rect.x += ball_speed[0]
    ball_rect.y += ball_speed[1]

    # Põrge seintest
    if ball_rect.left <= 0 or ball_rect.right >= WIDTH:
        ball_speed[0] = -ball_speed[0]
    if ball_rect.top <= 0:
        ball_speed[1] = -ball_speed[1]

    # Kokkupõrge alusega
    if ball_rect.colliderect(pad_rect) and ball_speed[1] > 0:
        ball_speed[1] = -ball_speed[1]
        score += 1

    # Kui pall puudutab alumist äärt
    if ball_rect.bottom >= HEIGHT:
        score -= 1
        ball_rect.center = (WIDTH // 2, HEIGHT // 2)
        ball_speed = [5, 5]

    # Tühjenda mänguaken
    screen.fill(LIGHT_BLUE)

    # Kuva mänguobjektid
    screen.blit(ball_img, ball_rect)
    screen.blit(pad_img, pad_rect)

    # Kuva skoor
    font = pygame.font.Font(None, 36)
    score_text = font.render(f"Score: {score}", True, WHITE)
    screen.blit(score_text, (10, 10))

    # Värskenda ekraan
    pygame.display.flip()

    # FPS
    pygame.time.Clock().tick(60)
pygame.quit()

