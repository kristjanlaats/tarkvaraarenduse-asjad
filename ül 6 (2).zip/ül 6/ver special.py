#kristjan.laats
import pygame
import sys

# Initsialiseeri pygame
pygame.init()

# Mängualuse laius ja kõrgus
WIDTH, HEIGHT = 640, 480

# Värvid
WHITE = (255, 255, 255)
LIGHT_BLUE = (173, 216, 230)

# Mänguaken
#ekraani seaded
screenX = 640
screenY = 480
screen=pygame.display.set_mode([screenX,screenY])
pygame.display.set_caption("Klaviatuuriga juhtimine")
screen.fill(LIGHT_BLUE)
clock = pygame.time.Clock()
# FPS

# Lae pildid
ball_img = pygame.image.load("ball.png")
pad_img = pygame.image.load("pad.png")

# Muuda palli ja aluse suurust
ball_img = pygame.transform.scale(ball_img, (20, 20))
pad_img = pygame.transform.scale(pad_img, (120, 20))

# Mänguobjektide algväärtused
ball_rect = ball_img.get_rect(center=(WIDTH // 2, HEIGHT // 2))
pad_rect = pad_img.get_rect(midbottom=(WIDTH // 2, int(HEIGHT / 1.5)))

# Kiirus ja suund
ball_speed = [5, 5]
pad_speed = 5

# Mängu oleku muutujad
score = 0

#koordinaadid ja kiirus
posX, posY = screenX/2, screenY/2
speedX, speedY = 0, 0
directionX, directionY = 0, 0

game_over = False

for event in pygame.event.get():
    if event.type == pygame.QUIT:
        gameover = True

        #klahvivajutus
    elif event.type == pygame.KEYDOWN:
        if event.key == pygame.K_RIGHT:
            directionX = "move_right"
        elif event.key == pygame.K_LEFT:
            directionX = "move_left"

    #mängu piirjoonte tuvastamine
if directionX == "move_left":
    if posX > 0:
        posX -= 3
elif directionX == "move_right":
    if posX + 30 < screenX:
        posX += 3


# Mängutsükkel
while not game_over:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()


        #klahvivajutuse vabastamine
        elif event.type == pygame.KEYUP:
            if event.key == pygame.K_RIGHT or event.key == pygame.K_LEFT:
                directionX = 0 
            if event.key == pygame.K_UP or event.key == pygame.K_DOWN:
                directionY = 0 

    #mängu piirjoonte tuvastamine
    if directionX == "move_left":
        if posX > 0:
            posX -= 3
    elif directionX == "move_right":
        if posX + 30 < screenX:
            posX += 3


    # Liiguta palli
    ball_rect.x += ball_speed[0]
    ball_rect.y += ball_speed[1]

    # Põrge seintest
    if ball_rect.left <= 0 or ball_rect.right >= WIDTH:
        ball_speed[0] = -ball_speed[0]
    if ball_rect.top <= 0:
        ball_speed[1] = -ball_speed[1]

    # Kokkupõrge alusega
    if ball_rect.colliderect(pad_rect) and ball_speed[1] > 0:
        ball_speed[1] = -ball_speed[1]
        score += 1

    # Kui pall puudutab alumist äärt
    if ball_rect.bottom >= HEIGHT:
        score -= 1
        ball_rect.center = (WIDTH // 2, HEIGHT // 2)
        ball_speed = [5, 5]

    # Kuva mänguobjektid
    screen.blit(ball_img, ball_rect)
    screen.blit(pad_img, pad_rect)

    # Kuva skoor
    font = pygame.font.Font(None, 36)
    score_text = font.render(f"Score: {score}", True, WHITE)
    screen.blit(score_text, (10, 10))

    # Värskenda ekraan
    pygame.display.flip()
    
    pygame.time.Clock().tick(60)
 
gameover = False
while not gameover:
    clock.tick(60)


    screen.fill(lBlue)
pygame.quit()