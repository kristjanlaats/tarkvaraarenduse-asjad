import pygame
import sys
import random

# Initsialiseeri pygame
pygame.init()
pygame.mixer.init()

# Mängualuse laius ja kõrgus
WIDTH, HEIGHT = 640, 480

# Värvid
WHITE = (255, 255, 255)
LIGHT_BLUE = (173, 216, 230)

# Mänguaken
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Klaviatuuriga juhtimine")
screen.fill(LIGHT_BLUE)
clock = pygame.time.Clock()

# Lae pildid
ball_img = pygame.image.load("ball.png")
pad_img = pygame.image.load("pad.png")

# Muuda palli ja aluse suurust
ball_img = pygame.transform.scale(ball_img, (20, 20))
pad_img = pygame.transform.scale(pad_img, (120, 20))

# Mänguobjektide algväärtused
ball_rect = ball_img.get_rect(center=(WIDTH // 2, HEIGHT // 2))
pad_rect = pad_img.get_rect(midbottom=(WIDTH // 2, HEIGHT - 30))

# Kiirus ja suund
ball_speed = [5, 5]
pad_speed = 6

# Mängu oleku muutujad
score = 0
game_over = False

# List of sound files
sounds = ['snd1.mp3', 'snd2.mp3', 'snd3.mp3', 'snd4.mp3', 'snd5.mp3']

# Randomly select a sound file
selected_sound = random.choice(sounds)

# Load the selected sound file
pygame.mixer.music.load(selected_sound)

# Play the loaded sound file
pygame.mixer.music.play(-1)  # Loop the music

# Set the volume
pygame.mixer.music.set_volume(0.2)

# Mängutsükkel
while not game_over:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            game_over = True

    # Get keys pressed
    keys = pygame.key.get_pressed()

    # Liiguta alust
    if keys[pygame.K_LEFT] and pad_rect.left > 0:
        pad_rect.x -= pad_speed
    if keys[pygame.K_RIGHT] and pad_rect.right < WIDTH:
        pad_rect.x += pad_speed

    # Liiguta palli
    ball_rect.x += ball_speed[0]
    ball_rect.y += ball_speed[1]

    # Põrge seintest
    if ball_rect.left <= 0 or ball_rect.right >= WIDTH:
        ball_speed[0] = -ball_speed[0]
    if ball_rect.top <= 0:
        ball_speed[1] = -ball_speed[1]

    # Kokkupõrge alusega
    if ball_rect.colliderect(pad_rect) and ball_speed[1] > 0:
        ball_speed[1] = -ball_speed[1]
        score += 1

    # Kui pall puudutab alumist äärt
    if ball_rect.bottom >= HEIGHT:
        game_over = True

    # Tühjenda mänguaken
    screen.fill(LIGHT_BLUE)

    # Kuva mänguobjektid
    screen.blit(ball_img, ball_rect)
    screen.blit(pad_img, pad_rect)

    # Kuva skoor
    font = pygame.font.Font(None, 36)
    score_text = font.render(f"Score: {score}", True, WHITE)
    screen.blit(score_text, (10, 10))

    # Värskenda ekraan
    pygame.display.flip()

    clock.tick(60)

pygame.quit()
sys.exit()
